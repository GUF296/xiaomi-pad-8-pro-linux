#!/usr/bin/env python3
"""Verify an optional, user-supplied firmware stage without downloading it."""
from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import sys

REQUIRED = (
    "lib/firmware/qcom/sm8750/xiaomi/piano/adsp.mbn",
    "lib/firmware/qcom/sm8750/xiaomi/piano/adsp_dtb.mbn",
    "lib/firmware/qcom/sm8750/xiaomi/piano/cdsp.mbn",
    "lib/firmware/qcom/sm8750/xiaomi/piano/cdsp_dtb.mbn",
    "lib/firmware/novatek/nt36532-piano-boe.bin",
    "lib/firmware/novatek/nt36532-piano-csot.bin",
    "lib/firmware/nanosic/MCU_Upgrade.bin",
)

# Presence is diagnostic: board data still needs device-specific compatibility testing.
RADIO = (
    # wifi7/hw.c selects WCN7860/hw2.0 for PCI ID 0x110e.
    "lib/firmware/ath12k/WCN7860/hw2.0/firmware-2.bin",
    "lib/firmware/ath12k/WCN7860/hw2.0/board-2.bin",
)


def normalize(raw: str, stage: Path) -> str:
    value = raw.replace("\\", "/")
    prefix = stage.name.rstrip("/") + "/"
    if value.startswith(prefix):
        value = value[len(prefix):]
    path = PurePosixPath(value)
    if path.is_absolute() or ".." in path.parts or "." in path.parts:
        raise ValueError(f"unsafe manifest path: {raw!r}")
    result = path.as_posix()
    if not result.startswith("lib/firmware/"):
        raise ValueError(f"path is outside copied firmware tree: {raw!r}")
    return result


def load_manifest(stage: Path) -> dict[str, dict[str, object]]:
    with (stage / "manifest.json").open(encoding="utf-8") as handle:
        document = json.load(handle)
    entries = document if isinstance(document, list) else document.get("files")
    if not isinstance(entries, list):
        raise ValueError("manifest must be a list or an object with a files list")
    if not entries:
        raise ValueError("firmware manifest is empty")
    result: dict[str, dict[str, object]] = {}
    for entry in entries:
        if not isinstance(entry, dict) or not isinstance(entry.get("path"), str):
            raise ValueError("manifest entry must contain a path")
        relative = normalize(entry["path"], stage)
        if relative in result:
            raise ValueError(f"duplicate manifest path: {relative}")
        result[relative] = entry
    return result


def verify(stage: Path, require_required: bool) -> dict[str, object]:
    if not stage.is_dir():
        raise ValueError(f"firmware stage does not exist: {stage}")
    manifest = load_manifest(stage)
    verified: list[str] = []
    for relative, entry in manifest.items():
        path = stage / relative
        if any(parent.is_symlink() for parent in [path, *path.parents] if parent != stage.parent):
            raise ValueError(f"symlink in firmware path: {relative}")
        if not path.is_file():
            raise ValueError(f"manifest file is absent or symlink: {relative}")
        expected_size = entry.get("bytes")
        expected_hash = entry.get("sha256")
        if not isinstance(expected_size, int) or not isinstance(expected_hash, str):
            raise ValueError(f"manifest entry lacks bytes/sha256: {relative}")
        actual_size = path.stat().st_size
        actual_hash = hashlib.sha256(path.read_bytes()).hexdigest()
        if actual_size != expected_size or actual_hash != expected_hash:
            raise ValueError(f"checksum mismatch: {relative}")
        verified.append(relative)

    firmware_root = stage / "lib/firmware"
    if any(path.is_symlink() for path in firmware_root.rglob("*")):
        raise ValueError("symlink found in firmware tree")
    actual_files = {
        path.relative_to(stage).as_posix()
        for path in firmware_root.rglob("*")
        if path.is_file() and not path.is_symlink()
    }
    extras = sorted(actual_files - set(manifest))
    if extras:
        raise ValueError("unlisted firmware files: " + ", ".join(extras[:8]))
    missing = sorted(set(manifest) - actual_files)
    if missing:
        raise ValueError("manifest files missing: " + ", ".join(missing[:8]))
    required_missing = sorted(set(REQUIRED) - set(manifest))
    if require_required and required_missing:
        raise ValueError("required device firmware missing: " + ", ".join(required_missing))
    return {"device_stage_supplied": True, "verified_files": len(verified),
            "required_missing": required_missing,
            "radio_files_missing": sorted(set(RADIO) - set(manifest)),
            "note": "Hashes verified; firmware compatibility and hardware functions are untested"}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("stage", type=Path)
    parser.add_argument("--allow-incomplete", action="store_true")
    args = parser.parse_args()
    try:
        result = verify(args.stage.resolve(), not args.allow_incomplete)
    except (OSError, ValueError, json.JSONDecodeError) as error:
        print(f"firmware verification failed: {error}", file=sys.stderr)
        return 1
    print(json.dumps(result, sort_keys=True))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
