#!/usr/bin/env bash
# Build only when explicitly run. This script is not run by the local validation.
set -Eeuo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd -P)"
SRC_DIR="${SRC_DIR:-$ROOT_DIR/.kernel-src}"
OUT_DIR="${OUT_DIR:-$ROOT_DIR/kernel-out}"
MODULES_DIR="${MODULES_DIR:-$ROOT_DIR/kernel-modules}"
ARTIFACT_DIR="${ARTIFACT_DIR:-$ROOT_DIR/kernel-artifacts}"
readonly KERNEL_COMMIT=469998695964bc26493861cd11f8c17aa764f2e5
readonly KERNEL_REPO=https://github.com/BigfootACA/linux.git
die() { printf 'error: %s\n' "$*" >&2; exit 1; }

if [[ ! -d "$SRC_DIR/.git" ]]; then
  [[ ! -e "$SRC_DIR" ]] || die "source directory exists but is not a git checkout"
  git init "$SRC_DIR"
  git -C "$SRC_DIR" remote add origin "$KERNEL_REPO"
  git -C "$SRC_DIR" fetch --no-tags --depth=1 origin "$KERNEL_COMMIT"
  git -C "$SRC_DIR" checkout --detach FETCH_HEAD
fi
[[ "$(git -C "$SRC_DIR" rev-parse HEAD)" == "$KERNEL_COMMIT" ]] || die "source commit mismatch"
[[ -z "$(git -C "$SRC_DIR" status --porcelain)" ]] || die "source checkout must be clean"
for directory in "$OUT_DIR" "$MODULES_DIR" "$ARTIFACT_DIR"; do
  [[ ! -e "$directory" ]] || die "use a fresh output directory: $directory"
  mkdir -p "$directory"
done
export KBUILD_BUILD_USER=piano KBUILD_BUILD_HOST=builder KBUILD_BUILD_VERSION=1
export KBUILD_BUILD_TIMESTAMP="$(git -C "$SRC_DIR" show -s --format=%cD HEAD)"
make -C "$SRC_DIR" O="$OUT_DIR" ARCH=arm64 LLVM=1 defconfig
KCONFIG_CONFIG="$OUT_DIR/.config" "$SRC_DIR/scripts/kconfig/merge_config.sh" \
  -m "$OUT_DIR/.config" "$ROOT_DIR/piano.config"
make -C "$SRC_DIR" O="$OUT_DIR" ARCH=arm64 LLVM=1 olddefconfig
for symbol in PHY_QCOM_QMP PHY_QCOM_QMP_UFS SCSI_UFS_QCOM EXT4_FS \
              DEVTMPFS DEVTMPFS_MOUNT EFI_STUB EFI_ARMSTUB_DTB_LOADER BLK_DEV_INITRD; do
  grep -qx "CONFIG_${symbol}=y" "$OUT_DIR/.config" || die "$symbol must be built in"
done
make -C "$SRC_DIR" O="$OUT_DIR" ARCH=arm64 LLVM=1 -j"${JOBS:-$(nproc)}" \
  Image Image.gz dtbs modules
KVER="$(make -s --no-print-directory -C "$SRC_DIR" O="$OUT_DIR" ARCH=arm64 LLVM=1 kernelrelease)"
[[ "$KVER" == 7.1.3-piano ]] || die "unexpected kernelrelease: $KVER"
make -C "$SRC_DIR" O="$OUT_DIR" ARCH=arm64 LLVM=1 \
  INSTALL_MOD_PATH="$MODULES_DIR" INSTALL_MOD_STRIP=1 modules_install
depmod -b "$MODULES_DIR" "$KVER"
[[ -s "$MODULES_DIR/lib/modules/$KVER/modules.dep" ]] || die "modules.dep missing"
# Never ship build-machine paths as module links.
rm -f "$MODULES_DIR/lib/modules/$KVER/build" "$MODULES_DIR/lib/modules/$KVER/source"
cp "$OUT_DIR/arch/arm64/boot/Image" "$ARTIFACT_DIR/Image"
cp "$OUT_DIR/arch/arm64/boot/Image.gz" "$ARTIFACT_DIR/Image.gz"
cp "$OUT_DIR/arch/arm64/boot/dts/qcom/sm8750-xiaomi-piano.dtb" "$ARTIFACT_DIR/piano.dtb"
cp "$OUT_DIR/.config" "$ARTIFACT_DIR/kernel.config"
cp "$OUT_DIR/System.map" "$ARTIFACT_DIR/System.map"
printf '%s\n' "$KVER" > "$ARTIFACT_DIR/kernelrelease"
printf '%s\n' "$KERNEL_COMMIT" > "$ARTIFACT_DIR/source-commit"
tar --sort=name --mtime='UTC 1970-01-01' --owner=0 --group=0 --numeric-owner \
  -C "$MODULES_DIR/lib/modules" -czf "$ARTIFACT_DIR/modules.tar.gz" "$KVER"
(cd "$ARTIFACT_DIR"; sha256sum Image Image.gz piano.dtb kernel.config System.map \
  kernelrelease source-commit modules.tar.gz > SHA256SUMS)
printf 'kernel artifact ready: %s (%s)\n' "$ARTIFACT_DIR" "$KVER"
