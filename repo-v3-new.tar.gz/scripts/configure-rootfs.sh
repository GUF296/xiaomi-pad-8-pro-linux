#!/usr/bin/env bash
# Native ARM64, root. No service is started in the chroot.
set -Eeuo pipefail
ROOTFS="$(realpath "${1:?ROOTFS required}")"
KVER="${2:?kernelrelease required}"
FIRMWARE_STAGE="${3:-}"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd -P)"
die() { printf 'error: %s\n' "$*" >&2; exit 1; }
[[ $EUID == 0 ]] || die "root is required for mounts/chroot"
[[ "$KVER" == 7.1.3-piano ]] || die "unexpected kernelrelease"
[[ -x "$ROOTFS/usr/bin/apt-get" ]] || die "apt-get missing"
[[ ! -e "$ROOTFS/usr/sbin/policy-rc.d" ]] || die "unexpected preexisting policy-rc.d"
if [[ -n "$FIRMWARE_STAGE" ]]; then
  # Verify before apt; copy only after apt so vendor files win.
  python3 "$SCRIPT_DIR/verify-firmware.py" "$FIRMWARE_STAGE" >/dev/null
else
  printf "warning: no firmware stage supplied; device firmware is intentionally absent\n" >&2
fi
MOUNTS=()
BACKUP_DIR="$(mktemp -d)"
HAD_RESOLV=0
SUCCESS=0
cleanup() {
  local status=$?
  trap - EXIT
  set +e
  for ((i=${#MOUNTS[@]}-1; i>=0; i--)); do
    umount -R "${MOUNTS[$i]}" 2>/dev/null || true
  done
  rm -f "$ROOTFS/usr/sbin/policy-rc.d" "$ROOTFS/etc/resolv.conf"
  if [[ "$SUCCESS" == 1 ]]; then
    ln -s ../run/systemd/resolve/stub-resolv.conf "$ROOTFS/etc/resolv.conf"
  elif [[ "$HAD_RESOLV" == 1 ]]; then
    cp -a "$BACKUP_DIR/resolv.conf" "$ROOTFS/etc/resolv.conf"
  fi
  rm -rf "$BACKUP_DIR"
  exit "$status"
}
trap cleanup EXIT
trap 'exit 130' INT
trap 'exit 143' TERM
if [[ -e "$ROOTFS/etc/resolv.conf" || -L "$ROOTFS/etc/resolv.conf" ]]; then
  cp -a "$ROOTFS/etc/resolv.conf" "$BACKUP_DIR/resolv.conf"
  HAD_RESOLV=1
fi
rm -f "$ROOTFS/etc/resolv.conf"
cp -L /etc/resolv.conf "$ROOTFS/etc/resolv.conf"
for name in dev proc sys run; do install -d "$ROOTFS/$name"; done
mount --rbind /dev "$ROOTFS/dev"; MOUNTS+=("$ROOTFS/dev")
mount --make-rslave "$ROOTFS/dev"
mount -t proc proc "$ROOTFS/proc"; MOUNTS+=("$ROOTFS/proc")
mount -t sysfs sysfs "$ROOTFS/sys"; MOUNTS+=("$ROOTFS/sys")
mount -t tmpfs tmpfs "$ROOTFS/run"; MOUNTS+=("$ROOTFS/run")
install -d "$ROOTFS/etc/apt/sources.list.d" "$ROOTFS/etc/apt/preferences.d"
cat > "$ROOTFS/etc/apt/preferences.d/nosnap.pref" <<'PREF'
Package: snapd
Pin: release a=*
Pin-Priority: -10
PREF
printf '#!/bin/sh\nexit 101\n' > "$ROOTFS/usr/sbin/policy-rc.d"
chmod 755 "$ROOTFS/usr/sbin/policy-rc.d"
cat > "$ROOTFS/etc/apt/sources.list.d/ubuntu.sources" <<'SOURCES'
Types: deb
URIs: https://ports.ubuntu.com/ubuntu-ports
Suites: noble noble-updates noble-backports
Components: main restricted universe multiverse
Signed-By: /usr/share/keyrings/ubuntu-archive-keyring.gpg

Types: deb
URIs: https://ports.ubuntu.com/ubuntu-ports
Suites: noble-security
Components: main restricted universe multiverse
Signed-By: /usr/share/keyrings/ubuntu-archive-keyring.gpg
SOURCES
rm -f "$ROOTFS/etc/apt/sources.list"
# Explicit full desktop/application set; no Firefox snap or SSH server.
chroot "$ROOTFS" /usr/bin/env DEBIAN_FRONTEND=noninteractive /bin/bash -euo pipefail <<'INSTALL'
apt-get update
apt-get install -y --no-install-recommends \
  systemd systemd-sysv systemd-resolved systemd-timesyncd udev dbus dbus-user-session \
  libpam-systemd sudo kmod initramfs-tools busybox e2fsprogs locales tzdata \
  ca-certificates linux-firmware network-manager network-manager-gnome wpasupplicant \
  wireless-regdb bluez gnome-core gnome-session gnome-initial-setup gdm3 \
  gnome-terminal gnome-tweaks gnome-software gnome-calendar gnome-clocks gnome-weather \
  gnome-system-monitor gnome-disk-utility gnome-calculator gnome-text-editor \
  nautilus evince eog file-roller seahorse baobab simple-scan epiphany-browser \
  libreoffice libreoffice-gnome xdg-desktop-portal-gnome xorg xwayland \
  libgl1-mesa-dri mesa-vulkan-drivers pipewire pipewire-alsa pipewire-pulse wireplumber \
  alsa-utils alsa-ucm-conf fonts-dejavu fonts-noto-color-emoji
if apt-get install -s snapd >/dev/null 2>&1; then
  echo "snapd pin did not hold" >&2
  exit 1
fi
# Do not create a normal user: GDM must launch new-user Initial Setup.
! awk -F: '$3 >= 1000 && $3 < 65534 { found=1 } END { exit !found }' /etc/passwd
passwd -l root
cat > /etc/gdm3/custom.conf <<'GDM'
[daemon]
InitialSetupEnable=true
GDM
# Keep the distro gnome-initial-setup vendor policy; no user/password is embedded.
printf '/usr/sbin/gdm3\n' > /etc/X11/default-display-manager
ln -sf /usr/lib/systemd/system/gdm3.service /etc/systemd/system/display-manager.service
systemctl enable NetworkManager.service systemd-resolved.service systemd-timesyncd.service
systemctl set-default graphical.target
printf 'piano\n' > /etc/hostname
printf '127.0.0.1 localhost\n127.0.1.1 piano\n::1 localhost ip6-localhost\n' > /etc/hosts
printf 'CHASSIS=tablet\n' > /etc/machine-info
printf 'LANG=C.UTF-8\n' > /etc/default/locale
printf 'LABEL=linux / ext4 defaults,x-systemd.growfs 0 1\n' > /etc/fstab
INSTALL
# Copy device files after package installation, before initramfs generation.
install -d "$ROOTFS/usr/share/piano-build"
if [[ -n "$FIRMWARE_STAGE" ]]; then
  python3 "$SCRIPT_DIR/verify-firmware.py" "$FIRMWARE_STAGE" \
    > "$ROOTFS/usr/share/piano-build/firmware-status.json"
  cp -a "$FIRMWARE_STAGE/lib/firmware/." "$ROOTFS/lib/firmware/"
  cp "$FIRMWARE_STAGE/manifest.json" "$ROOTFS/usr/share/piano-build/firmware-manifest.json"
else
  printf '{"device_stage_supplied":false,"note":"Only Ubuntu linux-firmware is installed; piano vendor firmware not supplied"}\n' \
    > "$ROOTFS/usr/share/piano-build/firmware-status.json"
fi
chroot "$ROOTFS" /usr/bin/env KVER="$KVER" /bin/bash -euo pipefail <<'FINALIZE'
depmod -a "$KVER"
test -s "/lib/modules/$KVER/modules.dep"
printf 'MODULES=most\nCOMPRESS=gzip\n' > /etc/initramfs-tools/conf.d/piano
# Storage is built in. Explicit graphics/input modules pull dependencies.
printf 'msm\npanel-novatek-nt36532\nktz8866\nnovatek-nt36532\n' > /etc/initramfs-tools/modules
# Include the verified device firmware tree even if MODULE_FIRMWARE lacks a name.
cat > /etc/initramfs-tools/hooks/piano-firmware <<'HOOK'
#!/bin/sh
set -e
case "$1" in prereqs) exit 0;; esac
for path in novatek/nt36532-piano-boe.bin novatek/nt36532-piano-csot.bin nanosic/MCU_Upgrade.bin; do
  if [ -e "/lib/firmware/$path" ]; then
    mkdir -p "$DESTDIR/lib/firmware/$(dirname "$path")"
    cp -a "/lib/firmware/$path" "$DESTDIR/lib/firmware/$path"
  fi
done
HOOK
chmod 755 /etc/initramfs-tools/hooks/piano-firmware
update-initramfs -c -k "$KVER"
test -s "/boot/initrd.img-$KVER"
lsinitramfs "/boot/initrd.img-$KVER" > /usr/share/piano-build/initramfs-contents.txt
grep -q 'panel-novatek-nt36532.ko' /usr/share/piano-build/initramfs-contents.txt
grep -q '/msm.ko' /usr/share/piano-build/initramfs-contents.txt
for package in gnome-core gnome-initial-setup gnome-session gdm3 network-manager wireplumber; do
  test "$(dpkg-query -W -f='${Status}' "$package")" = 'install ok installed'
done
test -x /usr/libexec/gnome-initial-setup
test -f /usr/share/gnome-session/sessions/gnome-initial-setup.session
test "$(readlink /etc/systemd/system/default.target)" = /usr/lib/systemd/system/graphical.target \
  || test "$(readlink /etc/systemd/system/default.target)" = /lib/systemd/system/graphical.target
test -e /etc/systemd/system/display-manager.service
systemctl is-enabled NetworkManager.service
! dpkg-query -W -f='${Status}' openssh-server 2>/dev/null | grep -q 'install ok installed'
dpkg-query -W -f='${Package}\t${Version}\n' > /usr/share/piano-build/packages.tsv
: > /etc/machine-id
rm -f /var/lib/dbus/machine-id
ln -s /etc/machine-id /var/lib/dbus/machine-id
apt-get clean
rm -rf /var/lib/apt/lists/*
FINALIZE
SUCCESS=1
