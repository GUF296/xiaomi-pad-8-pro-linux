#!/usr/bin/env bash
# Native ARM64/root build from the signed Ubuntu archive. Never flashes a device.
set -Eeuo pipefail
ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd -P)"
ROOTFS_TREE="${ROOTFS_TREE:-$ROOT_DIR/rootfs-tree}"
OUTPUT_DIR="${OUTPUT_DIR:-$ROOT_DIR/rootfs-artifacts}"
ROOTFS_SIZE="${ROOTFS_SIZE:-12G}"
KERNEL_ARTIFACT_DIR="${KERNEL_ARTIFACT_DIR:-$ROOT_DIR/kernel-artifacts}"
FIRMWARE_STAGE="${FIRMWARE_STAGE:-}"
die() { printf 'error: %s\n' "$*" >&2; exit 1; }
[[ $EUID == 0 ]] || die "root is required"
[[ "$(uname -m)" == aarch64 ]] || die "run on a native ARM64 host"
[[ "$ROOTFS_SIZE" =~ ^[1-9][0-9]*(G|M)$ ]] || die "rootfs size must be e.g. 12G"
[[ ! -e "$ROOTFS_TREE" && ! -e "$OUTPUT_DIR" ]] || die "use fresh rootfs/output directories"
for name in SHA256SUMS kernelrelease source-commit Image piano.dtb kernel.config System.map modules.tar.gz; do
  [[ -s "$KERNEL_ARTIFACT_DIR/$name" ]] || die "missing kernel artifact: $name"
done
(cd "$KERNEL_ARTIFACT_DIR"; sha256sum --strict --check SHA256SUMS)
KVER="$(cat "$KERNEL_ARTIFACT_DIR/kernelrelease")"
[[ "$KVER" == 7.1.3-piano ]] || die "unexpected kernelrelease"
[[ "$(cat "$KERNEL_ARTIFACT_DIR/source-commit")" == 469998695964bc26493861cd11f8c17aa764f2e5 ]] || die "kernel source mismatch"
for symbol in PHY_QCOM_QMP PHY_QCOM_QMP_UFS SCSI_UFS_QCOM EFI_STUB; do
  grep -qx "CONFIG_${symbol}=y" "$KERNEL_ARTIFACT_DIR/kernel.config" || die "bad kernel config: $symbol"
done
if [[ -n "$FIRMWARE_STAGE" ]]; then
  FIRMWARE_STAGE="$(realpath "$FIRMWARE_STAGE")"
  python3 "$ROOT_DIR/scripts/verify-firmware.py" "$FIRMWARE_STAGE"
fi
# debootstrap verifies Ubuntu Release signatures with the distro keyring.
# Never pass --no-check-gpg or use an unverified cloud root tarball.
debootstrap --arch=arm64 --variant=minbase --merged-usr --force-check-gpg \
  --keyring=/usr/share/keyrings/ubuntu-archive-keyring.gpg \
  --include=ca-certificates,ubuntu-keyring noble "$ROOTFS_TREE" \
  https://ports.ubuntu.com/ubuntu-ports
install -d "$ROOTFS_TREE/usr/lib/modules" "$ROOTFS_TREE/boot"
tar -xzf "$KERNEL_ARTIFACT_DIR/modules.tar.gz" -C "$ROOTFS_TREE/usr/lib/modules"
cp "$KERNEL_ARTIFACT_DIR/Image" "$ROOTFS_TREE/boot/Image"
cp "$KERNEL_ARTIFACT_DIR/piano.dtb" "$ROOTFS_TREE/boot/piano.dtb"
cp "$KERNEL_ARTIFACT_DIR/kernel.config" "$ROOTFS_TREE/boot/config-$KVER"
cp "$KERNEL_ARTIFACT_DIR/System.map" "$ROOTFS_TREE/boot/System.map-$KVER"
"$ROOT_DIR/scripts/configure-rootfs.sh" "$ROOTFS_TREE" "$KVER" "$FIRMWARE_STAGE"
# configure-rootfs must have removed all mounts and temporary build policy.
! mountpoint -q "$ROOTFS_TREE/dev" || die "chroot mounts remain"
[[ ! -e "$ROOTFS_TREE/usr/sbin/policy-rc.d" ]] || die "build policy remains"
mkdir -p "$OUTPUT_DIR"
truncate -s "$ROOTFS_SIZE" "$OUTPUT_DIR/rootfs.img"
mkfs.ext4 -F -L linux -d "$ROOTFS_TREE" "$OUTPUT_DIR/rootfs.img"
e2fsck -fn "$OUTPUT_DIR/rootfs.img"
[[ "$(blkid -s LABEL -o value "$OUTPUT_DIR/rootfs.img")" == linux ]] || die "wrong filesystem label"
cp "$ROOTFS_TREE/boot/initrd.img-$KVER" "$OUTPUT_DIR/initrd.img"
cp "$KERNEL_ARTIFACT_DIR/Image" "$KERNEL_ARTIFACT_DIR/piano.dtb" "$OUTPUT_DIR/"
cp "$ROOTFS_TREE/usr/share/piano-build/"* "$OUTPUT_DIR/"
cp "$KERNEL_ARTIFACT_DIR/kernelrelease" "$KERNEL_ARTIFACT_DIR/source-commit" "$OUTPUT_DIR/"
printf 'root=LABEL=linux rootfstype=ext4 rw rootwait\n' > "$OUTPUT_DIR/cmdline.txt"
zstd -T0 -10 --rm "$OUTPUT_DIR/rootfs.img"
(cd "$OUTPUT_DIR"; sha256sum ./* > SHA256SUMS)
printf 'rootfs artifact ready: %s (%s)\n' "$OUTPUT_DIR" "$KVER"
