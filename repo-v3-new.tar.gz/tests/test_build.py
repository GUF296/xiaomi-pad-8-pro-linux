import hashlib
import importlib.util
import json
from pathlib import Path
import subprocess
import tempfile
import unittest
import yaml

ROOT = Path(__file__).resolve().parents[1]


class FirmwareTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.root = Path(self.temp.name)

    def make_manifest(self, paths=None):
        paths = paths or ["novatek/nt36532-piano-boe.bin"]
        entries = []
        for name in paths:
            path = self.root / "lib/firmware" / name
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_bytes(b"fixture firmware")
            entries.append({"path": "lib/firmware/" + name,
                            "bytes": path.stat().st_size,
                            "sha256": hashlib.sha256(path.read_bytes()).hexdigest()})
        (self.root / "manifest.json").write_text(json.dumps(entries))
        return entries

    def run_validator(self):
        return subprocess.run(["python3", str(ROOT / "scripts/verify-firmware.py"),
                               str(self.root), "--allow-incomplete"],
                              capture_output=True, text=True)

    def test_accepts_matching_manifest(self):
        self.make_manifest()
        result = self.run_validator()
        self.assertEqual(result.returncode, 0, result.stderr)
        self.assertIn("verified_files", result.stdout)

    def test_rejects_corrupt_file(self):
        self.make_manifest()
        (self.root / "lib/firmware/novatek/nt36532-piano-boe.bin").write_bytes(b"bad")
        self.assertNotEqual(self.run_validator().returncode, 0)

    def test_rejects_unlisted_file(self):
        self.make_manifest()
        (self.root / "lib/firmware/unlisted.bin").write_bytes(b"bad")
        self.assertNotEqual(self.run_validator().returncode, 0)

    def test_rejects_traversal(self):
        entries = self.make_manifest()
        entries[0]["path"] = "lib/firmware/../../escape"
        (self.root / "manifest.json").write_text(json.dumps(entries))
        self.assertNotEqual(self.run_validator().returncode, 0)

    def test_rejects_symlink(self):
        self.make_manifest()
        path = self.root / "lib/firmware/novatek/nt36532-piano-boe.bin"
        path.unlink()
        path.symlink_to("/etc/hostname")
        self.assertNotEqual(self.run_validator().returncode, 0)

    def test_rejects_missing_file(self):
        self.make_manifest()
        (self.root / "lib/firmware/novatek/nt36532-piano-boe.bin").unlink()
        self.assertNotEqual(self.run_validator().returncode, 0)

    def test_requires_device_files_by_default(self):
        self.make_manifest()
        result = subprocess.run(["python3", str(ROOT / "scripts/verify-firmware.py"),
                                 str(self.root)], capture_output=True, text=True)
        self.assertNotEqual(result.returncode, 0)


class BuildContracts(unittest.TestCase):
    def test_required_files_exist(self):
        for name in ["piano.config", "scripts/build-kernel.sh", "scripts/build-rootfs.sh",
                     "scripts/configure-rootfs.sh", "scripts/verify-firmware.py",
                     ".github/workflows/build.yml", "README.md"]:
            self.assertTrue((ROOT / name).is_file(), name)

    def test_storage_parent_and_child_are_builtin(self):
        config = (ROOT / "piano.config").read_text()
        for symbol in ["PHY_QCOM_QMP", "PHY_QCOM_QMP_UFS", "SCSI_UFS_QCOM",
                       "EXT4_FS", "EFI_STUB", "BLK_DEV_INITRD"]:
            self.assertIn(f"CONFIG_{symbol}=y", config)

    def test_scripts_have_valid_bash_syntax(self):
        scripts = list((ROOT / "scripts").glob("*.sh"))
        self.assertGreaterEqual(len(scripts), 3)
        for script in scripts:
            subprocess.run(["bash", "-n", str(script)], check=True)


    def test_wifi_firmware_path_is_wcn7860(self):
        validator = (ROOT / "scripts/verify-firmware.py").read_text()
        self.assertIn("ath12k/WCN7860/hw2.0/firmware-2.bin", validator)
        self.assertNotIn("WCN7850/hw2.0/firmware-2.bin", validator)

    def test_workflow_splits_kernel_before_rootfs(self):
        workflow = yaml.safe_load((ROOT / ".github/workflows/build.yml").read_text())
        self.assertEqual(workflow["jobs"]["rootfs"]["needs"], "kernel")
        self.assertNotIn("mkbootimg", (ROOT / ".github/workflows/build.yml").read_text())
        self.assertIn("debootstrap", (ROOT / ".github/workflows/build.yml").read_text())

    def test_no_android_packager_or_passwords(self):
        for script in (ROOT / "scripts").glob("*.sh"):
            contents = script.read_text()
            self.assertNotIn("chpasswd", contents)
            self.assertNotIn("--header_version", contents)
            self.assertNotIn("curl", contents)
            self.assertNotIn("AutomaticLoginEnable=true", contents)


if __name__ == "__main__":
    unittest.main()
