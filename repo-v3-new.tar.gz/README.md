# Xiaomi Pad 8 Pro (piano) corrected build

This directory contains a corrected Ubuntu 24.04 arm64 GNOME build path. The
kernel source is pinned to BigfootACA/linux commit
`469998695964bc26493861cd11f8c17aa764f2e5`; `piano.config` is merged as an
additive fragment over arm64 `defconfig`.

The kernel job publishes an uncompressed EFI-stub `Image`, DTB, deterministic
`kernelrelease`, config, System.map, and modules. The rootfs job consumes that
artifact, bootstraps Ubuntu through signed `debootstrap`, creates an ext4
filesystem labeled `linux`, installs a broad GNOME desktop, creates an initramfs
with storage/display modules, and configures GDM, GNOME Initial Setup,
NetworkManager, and graphical.target. No normal user, password, autologin, or SSH
server is embedded; first boot must create the user in GNOME Initial Setup.

Firmware is optional. A supplied stage must contain `manifest.json` plus the
piano vendor files and every copied file must match its declared size and
SHA-256. The verifier rejects corrupt, missing, extra, unsafe, or symlinked files.
The current local stage verifies its 83 vendor files but reports missing
`ath12k/WCN7860/hw2.0/{firmware-2.bin,board-2.bin}` radio data, so the build does
not claim Wi-Fi support. The verifier records that status in the rootfs artifact.

The output is a compressed bare ext4 image (`rootfs.img.zst`), `initrd.img`,
`Image`, `piano.dtb`, command line, package list, and checksums. A device-specific
UEFI ESP, DTB handoff, partition LABEL/UUID, and signed boot chain still need to
be defined and hardware-tested. Android boot-image packaging is intentionally
left out until its exact ABL header, AVB, and partition procedure is known.
