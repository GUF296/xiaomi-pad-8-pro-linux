# Corrected piano image build

- Kernel job first: pin and verify commit 469998695964bc26493861cd11f8c17aa764f2e5,
  merge the additive piano fragment over defconfig, build uncompressed EFI Image,
  DTB, modules, and deterministic module indexes, then upload the artifact.
- Rootfs job second: reuse the kernel artifact, run signed Ubuntu debootstrap on
  native arm64, mount and clean chroot virtual filesystems with traps, install a
  full GNOME set and GNOME Initial Setup, create initramfs, configure LABEL=linux
  and graphical target, and leave credentials/user creation to first boot.
- Firmware is optional and never fetched. A supplied stage is copied only after
  strict manifest verification. Radio data is reported as missing when absent;
  the image never claims Wi-Fi support without it.
- Android boot-image packaging, partitioning, flashing, UEFI ESP creation, AVB,
  and hardware boot tests remain deliberately outside this build.

Local validation runs shell syntax, Python manifest tests, firmware checks, and
workflow structure checks. It does not download or execute kernel/rootfs code.
